#include <stdio.h>
#include <assert.h>

#include "list.h"

int test_dlist()
{
	int error = 0;
	struct DList *dlist = dlist_create();

	if (dlist_length(dlist) != 0) {
		printf("dlist_length of empty dlist should be zero\n");
		return 0;
	}


	// Insert value 101 and test functions
	dlist_insert(dlist, 0, 101);
	if (dlist_length(dlist) != 1) {
		printf("dlist_length should be 1\n");
		return 0;
	}

	if (dlist_get(dlist, 0, &error) != 101) {
		printf("dlist_get should return value 101E\n");
		return 0;
	}
	if (error != 0) {
		printf("error in dlist_get (1)\n");
		return 0;
	}


	// Insert value 202 and test functions
	dlist_insert(dlist, 0, 202);
	if (dlist_length(dlist) != 2) {
		printf("dlist_length should return 2\n");
		return 0;
	}

	if (dlist_get(dlist, 0, &error) != 202) {
		printf("dlist_get should return 202\n");
		return 0;
	}
	if (error != 0) {
		printf("Error in dlist_length (2)\n");
		return 0;
	}


	// Test remove function
	if (dlist_remove(dlist, 1) == 0) {
		printf("Error in dlist_remove\n");
		return 0;
	}
	if (dlist_length(dlist) != 1) {
		printf("dlist_length should return 1 (after remove)\n");
		return 0;
	}
	

	// Test prepend function
	dlist_prepend(dlist, 34);
	if (dlist_length(dlist) != 2) {
		printf("dlist_length should return 2 (after prepend)\n");
		return 0;
	}
	if (dlist_get(dlist, 0, &error) != 34) {
		printf("dlist_get should return 34 (after prepend)\n");
		return 0;
	}
	if (error != 0) {
		printf("Error in dlist_prepend (could not get value)\n");
		return 0;
	}


	// TODO: Add our own test functions (!!)

	return 1;
}


int test_tree()
{
	int value, error;

	struct TreeNode *valueNode1 = tree_node_from_value(6);
	struct TreeNode *valueNode2 = tree_node_from_value(10);
	struct TreeNode *operatorNode = tree_node_from_operator('+', valueNode1, valueNode2);
	struct Tree *tree = tree_create(operatorNode);

	tree_print(tree);
	value = tree_evaluate(tree, &error);
	if (error != 0) {
		printf("An error occurred while evaluting the example tree\n");
		return 0;
	}
	if (value != 16) {
		printf("Error while evaluating value of example tree: got %d but expected 16\n", value);
		return 0;
	}

	// TODO: Add your own test functions (!!)

	return 1;
}


int test_stack()
{
	// TODO: Add your own test functions (!!)

	return 1;
}


int test_expression(const char *expression, int expected)
{
	struct Tree *tree;
	int value, error;

	printf(">>> Testing expression: %s\n", expression);

	// Constructing tree and evaluating it
	tree = tree_from_expression(expression);
	if (tree == NULL) {
		printf("Failed to construct expression tree for %s\n", expression);
		return 0;
	}

	tree_print(tree);
	value = tree_evaluate(tree, &error);
	if (error != 0) {
		printf("Error argument set on evaluation of %s\n", expression);
		tree_delete(tree);
		return 0;
	}
	if (value != expected) {
		printf("Failed to evaluate %s to %d (got %d instead)\n", expression, expected, value);
		tree_delete(tree);
		return 0;
	}

	// Simplify one step and check result
	tree_simplify_onestep(tree);
	tree_print(tree);
	value = tree_evaluate(tree, &error);
	if (error != 0) {
		printf("Error argument set on evaluation of %s after simplifying tree\n", expression);
		tree_delete(tree);
		return 0;
	}
	if (value != expected) {
		printf("Failed to evaluate %s to %d after simplifying tree (got %d instead)\n",
			expression, expected, value);

		tree_delete(tree);
		return 0;
	}

	// Try another simplify step -- TODO: Keep trying to test simplify until tree can no longer be simplified
	tree_simplify_onestep(tree);
	tree_print(tree);
	value = tree_evaluate(tree, &error);
	if (error != 0) {
		printf("Error argument set on evaluation of %s after simplifying tree\n", expression);
		tree_delete(tree);
		return 0;
	}
	if (value != expected) {
		printf("Failed to evaluate %s to %d after simplifying tree (got %d instead)\n",
			expression, expected, value);

		tree_delete(tree);
		return 0;
	}

	tree_delete(tree);
	return 1;
}


int test_many_expressions()
{
	if (!test_expression("10", 10))
		return 0;

	if (!test_expression("6 4 +", 10))
		return 0;

	if (!test_expression("6 4 + 10 *", 100))
		return 0;

	if (!test_expression("6 4 + 10 * 1 -", 99))
		return 0;

	if (!test_expression("1 1 + 1 + 1 1 1 + + +", 6))
		return 0;

	// TODO: Add more test! For example: using negative numbers, testing
	// that tree_from_expression returns NULL on invalid expressions, etc.

	return 1;
}


int main(int argc, char *argv[])
{
	test_dlist();
	test_tree();
	test_stack();
	test_many_expressions();

	return 0;
}

