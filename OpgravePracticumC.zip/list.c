#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "list.h"

// ==================== Dubbel Gelinkte Lijst ====================

// Create an empty list
//
// Python: list = []
struct DList * dlist_create()
{
	struct DList *dlist = malloc(sizeof(struct DList));
	dlist->first = NULL;
	dlist->last = NULL;
	dlist->length = 0;
	return dlist;
}

// Print a human-readable representation of the given list
//
// Python: print(list)
void dlist_print(struct DList *dlist)
{
	printf("[");

	struct DListNode *current = dlist->first;

	while (current != NULL)
	{
		printf("%d", current->value);

		// no comma after last value
		if (current->next != NULL)
			printf(", ");

		current = current->next;
	}

	printf("]\n");
}

// Delete the given list
//
// Python: del list
void dlist_delete(struct DList *dlist)
{
	struct DListNode *curr = dlist->first;

	while (curr != NULL) {
		struct DListNode* todel = curr;
		curr = curr->next;
		free(todel);
	}
	
	free(dlist);
}

// Print the elements of the list in reverse order. For example, if the list contains
// the numbers 3, 7, and 1, it should print "[1, 7, 3]\n".
//
// Python: print(list[::-1])
void dlist_print_reverse(struct DList *dlist)
{
}

// Return the length of the given list (i.e., the number of values in it)
//
// Python: length = len(list)
int dlist_length(struct DList *dlist)
{
}


// Return the value of the element at the given index. If the given index is out of
// range, the memory location pointed to by error is set to 1 (and the value zero
// is returned), otherwise the memory location pointed to by error is set to 0.
//
// Python: value = list[i]
// (An IndexError would correspond to a return value of 0)
int dlist_get(struct DList *list, int index, int *error)
{
}

// Append the given value to the given list
//
// Python: list.append(value)
void dlist_append(struct DList *dlist, int value)
{
}

// Prepend the value to the front of the list.
//
// Python: list.insert(0, value)
void dlist_prepend(struct DList *dlist, int value)
{
}

// Insert the element before the given index in the list. A negative index
// means the element should be added to the front (prepended). An index that
// is too high means the element should be added to the back (appended).
//
// Python: list.insert(index, value)
// (Note that the behavior for negative indices differs slightly in Python)
void dlist_insert(struct DList *dlist, int index, int value)
{
}

// Remove the element at the given index from the given list. If the given index
// is out of range, 0 is returned, otherwise 1 is returned.
//
// Python: del list[i]
// (An IndexError would correspond to a return value of 0)
int dlist_remove(struct DList *dlist, int index)
{
}

// Insert the value at the correct position in a sorted list. Assume that the list
// is sorted from lowest to highest (ascending). The list must remain sorted!
void dlist_insert_sorted(struct DList *dlist, int value)
{
}

// Remove all values in the list that lie between lower and upper. That is, every value
// for which `lower <= value <= upper` is true, is removed from the list.
void dlist_remove_valuerange(struct DList *dlist, int lower, int upper)
{
}


// ==================== Binaire boom ====================

struct Tree * tree_create(struct TreeNode *topNode)
{
}

// Print the TreeNode as an infix expression using recursion
static void tree_print_node(struct TreeNode *node)
{
	if (node->operator == '\0')
	{
		printf("%d", node->value);
	}
	else
	{
		printf("(");
		tree_print_node(node->left);
		printf(" %c ", node->operator);
		tree_print_node(node->right);
		printf(")");
	}
}

// Print the binary tree as an infix pression
void tree_print(struct Tree *tree)
{
	tree_print_node(tree->top);
	printf("\n");
}

// Delete the TreeNode and all its children, children of children, and so on
//
// Hint: This is somewhat similar to the function tree_print_node, where the function
//       recursively calls itself to print the left and right nodes (if not equal to NULL).
static void tree_delete_node(struct TreeNode *node)
{
}

// Delete the binary tree and all its children, children of children, and so on.
void tree_delete(struct Tree *tree)
{
}


// Make a copy of the tree and return this copy. Remember that, for all functions you have
// to implement, you are allowed to use helper functions and recursion.
struct Tree * tree_copy(struct Tree *tree)
{
}

// Create a node from a value. The fields left and right must be set so NULL. The field
// operator must be set to '\0'.
struct TreeNode * tree_node_from_value(int value)
{
}

// Create a node from an operator and it's two operands. The operator is given as an ASCII character,
// while the operands are given as nodes.
//
// Note that the newly created node becomes owner of the left and right nodes. That is, when the
// created (returned) node is freed, the given left and right node will also be freed.
struct TreeNode * tree_node_from_operator(char operator, struct TreeNode *left, struct TreeNode *right)
{
}


// Evaluate the binary expression tree given in parameter `tree`.
//
// Returns the value of the expression. If there was an error while evaluating the
// expression, zero is returned, and the memory pointed to by error is set to one.
// If there were no errors, the memory pointed to by error is set to zero.
int tree_evaluate(struct Tree *tree, int *error)
{
}

// ==================== Stacks ====================

// Create an empty stack
struct Stack * stack_create()
{
}

// Push a TreeNode on the stack
void stack_push(struct Stack* stack, struct TreeNode *node)
{
}

// Get the last TreeNode that was added to the stack and return it. If the stack is empty
// the memory location pointed to by error is set to 1 and NULL is returned. Otherwise the
// memory location pointed to by error is set to 0 and the last added node is returned.
struct TreeNode * stack_pop(struct Stack *stack, int *error)
{
}

// Returns 1 if the stack is empty (i.e. there are no nodes to pop).
// Otherwise it returns 0.
int stack_isempty(struct Stack *stack)
{
}

// Delete the given stack. When deleting a TreeNode, all its descendants (children nodes,
// children of children nodes, and so on) must also be deleted.
void stack_delete(struct Stack *stack)
{
}

// ==================== Postfix Expression ====================


// Convert the postfix expression given in parameter `formula` to a binary expression tree.
//
// Returns NULL if `formula` is an invalid postfix expression. Otherwise it returns the binary
// tree representing the expression.
struct Tree * tree_from_expression(const char *formula)
{
}


// Simplify the binary expression tree by replacing all operations on leaf nodes (i.e. values) by
// the result of the expression. For example, the expression `(1+(1+(1+1)))` is simplified to
// `(1+(1+2))`. Similarly, the expression `(1+((1+1)+1))` is simplified to `(1+(2+1))`. It can
// also happen that multiple operations can be simplified (i.e. there are multiple nodes where both
// the left and right node are values). For example, the expression `(((1+1)+1)+(1+(1+1)))` should
// be simplified to `((2+1)+(1+2))`.
//
// The tree is left unmodified if it cannot be simplified.
void tree_simplify_onestep(struct Tree *tree)
{
}

// Simplify the binary expression tree until it can no longer be simplified. Print out the tree after
// after each simplification. For example, when given the tree `(((1+1)+1)+(1+(1+1)))`, it should print:
//
//		(((1+1)+1)+(1+(1+1)))
//		((2+1)+(1+2))
//		(3+3)
//		6
//
// The tree given in the parameter `tree` should not be modified!
// Hint: use functions that you previously created/implemented.
void tree_evaluate_showsteps(struct Tree *tree, int *error)
{
}


